package mk.finki.ukim.mk.lab1.model.dto;

import mk.finki.ukim.mk.lab1.model.domain.Country;
import mk.finki.ukim.mk.lab1.model.domain.Host;

public record CreateHostDto(Country country, String surname, String name) {
    public Host toHost(){
        return new Host(country, surname, name);
    }
}
