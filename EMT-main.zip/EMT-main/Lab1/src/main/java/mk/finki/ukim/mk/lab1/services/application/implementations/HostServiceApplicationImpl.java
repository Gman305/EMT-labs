package mk.finki.ukim.mk.lab1.services.application.implementations;

import mk.finki.ukim.mk.lab1.model.domain.Host;
import mk.finki.ukim.mk.lab1.model.dto.DisplayHostDto;
import mk.finki.ukim.mk.lab1.services.domain.HostService;
import org.springframework.stereotype.Service;
import mk.finki.ukim.mk.lab1.services.application.HostApplicationService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class HostServiceApplicationImpl implements HostApplicationService {

    private final HostService hostService;

    public HostServiceApplicationImpl(HostService hostService) {
        this.hostService = hostService;
    }

    @Override
    public List<DisplayHostDto> findAll() {
        return this.hostService.findAll()
                .stream()
                .map(DisplayHostDto::from)
                .collect(Collectors.toList());
    }
}
