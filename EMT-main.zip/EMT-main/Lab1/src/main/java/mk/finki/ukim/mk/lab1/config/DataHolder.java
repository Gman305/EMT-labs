package mk.finki.ukim.mk.lab1.config;
import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab1.model.domain.Country;
import mk.finki.ukim.mk.lab1.model.domain.Host;
import mk.finki.ukim.mk.lab1.model.domain.User;
import mk.finki.ukim.mk.lab1.model.enumerations.Role;
import mk.finki.ukim.mk.lab1.repository.CountryRepository;
import mk.finki.ukim.mk.lab1.repository.HostRepository;
import mk.finki.ukim.mk.lab1.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataHolder {

    private final CountryRepository countryRepository;
    private final HostRepository hostRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataHolder(CountryRepository countryRepository, HostRepository hostRepository, UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.countryRepository = countryRepository;
        this.hostRepository = hostRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostConstruct
    public void init() {
        Country country1 = new Country("Macedonia","Europe");
        Country country2 = new Country("USA","America");
        Country country3 = new Country("India","Asia");

        this.countryRepository.save(country1);
        this.countryRepository.save(country2);
        this.countryRepository.save(country3);

        Host host1=new Host(country1,"Stojanovski","Petar");
        Host host2=new Host(country2,"Bacevac","Damir");
        Host host3=new Host(country3,"Jovanovski","Teodor");

        this.hostRepository.save(host1);
        this.hostRepository.save(host2);
        this.hostRepository.save(host3);

        userRepository.save(new User(
                "kole",
                passwordEncoder.encode("kole"),
                "User",
                "User",
                Role.ROLE_USER
        ));

        userRepository.save(new User(
                "peco",
                passwordEncoder.encode("peco"),
                "Host",
                "Host",
                Role.ROLE_HOST
        ));

   }
}
