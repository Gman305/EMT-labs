package mk.finki.ukim.mk.lab1.model.dto;

import mk.finki.ukim.mk.lab1.model.enumerations.Role;
import mk.finki.ukim.mk.lab1.model.domain.User;

public record CreateUserDto(String username,
                            String password,
                            String repeatPassword,
                            String name,
                            String surname,
                            Role role) {
    public User toUser() {
        return new User(username, password, name, surname, role);
    }
}
