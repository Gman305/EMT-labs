package mk.finki.ukim.mk.lab1.model.enumerations;

public enum BookCategory {
    ROOM,HOUSE,FLAT,APARTMENT,HOTEL,MOTEL
}
