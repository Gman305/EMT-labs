package mk.finki.ukim.mk.lab1.model.dto;

import mk.finki.ukim.mk.lab1.model.domain.Accomodation;
import mk.finki.ukim.mk.lab1.model.domain.Host;
import mk.finki.ukim.mk.lab1.model.enumerations.BookCategory;

public record CreateAccomodationDto(String name, BookCategory bookCategory, Host host, int numRooms) {
    public Accomodation toAccomodation() {
        return new Accomodation(name, bookCategory, host, numRooms);
    }
}
