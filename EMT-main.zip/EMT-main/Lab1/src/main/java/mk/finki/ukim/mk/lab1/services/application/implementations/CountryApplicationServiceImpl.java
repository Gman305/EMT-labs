package mk.finki.ukim.mk.lab1.services.application.implementations;

import mk.finki.ukim.mk.lab1.model.domain.Country;
import mk.finki.ukim.mk.lab1.model.dto.DisplayCountryDto;
import mk.finki.ukim.mk.lab1.services.domain.CountryService;
import org.springframework.stereotype.Service;
import mk.finki.ukim.mk.lab1.services.application.CountryApplicationService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CountryApplicationServiceImpl implements CountryApplicationService {

    private final CountryService countryService;

    public CountryApplicationServiceImpl(CountryService countryService) {
        this.countryService = countryService;
    }

    @Override
    public List<DisplayCountryDto> findAll() {
        return this.countryService.findAll()
                .stream()
                .map(DisplayCountryDto::from)
                .collect(Collectors.toList());
    }
}
