package mk.finki.ukim.mk.lab1.services.application;


import mk.finki.ukim.mk.lab1.model.domain.Accomodation;
import mk.finki.ukim.mk.lab1.model.domain.User;
import mk.finki.ukim.mk.lab1.model.dto.CreateUserDto;
import mk.finki.ukim.mk.lab1.model.dto.DisplayAccomodationDto;
import mk.finki.ukim.mk.lab1.model.dto.DisplayUserDto;
import mk.finki.ukim.mk.lab1.model.dto.LoginUserDto;
import mk.finki.ukim.mk.lab1.model.enumerations.Role;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;
import java.util.Optional;

public interface UserApplicationService extends UserDetailsService {
    Optional<DisplayUserDto> register(CreateUserDto createUserDto);

    Optional<DisplayUserDto> login(LoginUserDto loginUserDto);

    Optional<DisplayUserDto> findByUsername(String username);
    List<DisplayAccomodationDto> addToTemporaryReservationList(String username, Long id);
    List<DisplayAccomodationDto> getTemporaryReservationList(String username);
    List<DisplayAccomodationDto> confirmAllReservations(String username);
}
