package mk.finki.ukim.mk.lab1.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.finki.ukim.mk.lab1.model.domain.Host;
import mk.finki.ukim.mk.lab1.services.application.HostApplicationService;
import mk.finki.ukim.mk.lab1.model.dto.DisplayHostDto;
import mk.finki.ukim.mk.lab1.model.dto.CreateHostDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/hosts")
@Tag(name = "Host API", description = "Endpoints for managing hosts")
public class HostController {

    private final HostApplicationService hostApplicationService;

    public HostController(HostApplicationService hostApplicationService) {
        this.hostApplicationService = hostApplicationService;
    }

    @Operation(summary = "Get all hosts", description = "Returns all hosts")
    @GetMapping
    public List<DisplayHostDto> getAll() {
        return hostApplicationService.findAll();
    }
}
