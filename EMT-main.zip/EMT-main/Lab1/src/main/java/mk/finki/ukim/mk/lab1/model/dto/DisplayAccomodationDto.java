package mk.finki.ukim.mk.lab1.model.dto;

import mk.finki.ukim.mk.lab1.model.domain.Accomodation;
import mk.finki.ukim.mk.lab1.model.domain.Host;
import mk.finki.ukim.mk.lab1.model.enumerations.BookCategory;

import java.util.List;
import java.util.stream.Collectors;

public record DisplayAccomodationDto(Long id, BookCategory bookCategory, Host host, int numRooms) {
    public static DisplayAccomodationDto from(Accomodation accomodation) {
        return new DisplayAccomodationDto(accomodation.getId(), accomodation.getCategory(), accomodation.getHost(), accomodation.getNumRooms());
    }
    public static List<DisplayAccomodationDto> from(List<Accomodation> accomodations) {
        return accomodations.stream().map(DisplayAccomodationDto::from).collect(Collectors.toList());
    }
}
