package mk.finki.ukim.mk.lab1.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.finki.ukim.mk.lab1.model.AccomodationsDTO.AccomodationDto;
import mk.finki.ukim.mk.lab1.model.domain.Accomodation;
import mk.finki.ukim.mk.lab1.services.application.AccomodationApplicationService;
import mk.finki.ukim.mk.lab1.services.application.CountryApplicationService;
import mk.finki.ukim.mk.lab1.services.application.HostApplicationService;
import mk.finki.ukim.mk.lab1.model.dto.CreateAccomodationDto;
import mk.finki.ukim.mk.lab1.model.dto.DisplayAccomodationDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/accomodations")
@Tag(name = "Accomodation API", description = "Endpoints for managing accomodations")
public class AccomodationController {

    private final AccomodationApplicationService accomodationApplicationService;

    public AccomodationController(AccomodationApplicationService accomodationApplicationService) {
        this.accomodationApplicationService = accomodationApplicationService;
    }

    @Operation(summary = "Get all accomodations",description = "Retrieves all accomodations")
    @GetMapping
    public List<DisplayAccomodationDto> findAll() {
        return accomodationApplicationService.findAll();
    }

    @Operation(summary = "Create a new accomodation",description = "Creates a new accomodation")
    @PostMapping("/add-accomodation")
    public ResponseEntity<DisplayAccomodationDto> create(@RequestBody CreateAccomodationDto accomodationDto) {
        return accomodationApplicationService.create(accomodationDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @Operation(summary = "Edit an accomodation", description = "Allows you to edit an existing accomodation")
    @PutMapping("/edit-accomodations/{id}")
    public ResponseEntity<DisplayAccomodationDto> edit(@PathVariable long id,
                                             @RequestBody CreateAccomodationDto accomodationDto) {
        return accomodationApplicationService.update(id,accomodationDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @Operation(summary = "Delete accomodation", description = "Deletes an accomodation according to the id")
    @DeleteMapping("delete-accomodation/{id}")
    public ResponseEntity<Void> delete(@PathVariable long id) {
        if(accomodationApplicationService.findById(id).isPresent()) {
            accomodationApplicationService.delete(id);
            return ResponseEntity.noContent().build();
        }
        else{
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "Check reservation", description = "Checks if an accomodation is already reserved")
    @PostMapping("/reservation/{id}")
    public ResponseEntity<DisplayAccomodationDto> reservation(@PathVariable long id) {
        return accomodationApplicationService.reservation(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
