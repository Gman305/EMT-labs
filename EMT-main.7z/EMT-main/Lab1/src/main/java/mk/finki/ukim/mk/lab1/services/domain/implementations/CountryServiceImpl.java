package mk.finki.ukim.mk.lab1.services.domain.implementations;

import mk.finki.ukim.mk.lab1.model.domain.Country;
import mk.finki.ukim.mk.lab1.repository.CountryRepository;
import mk.finki.ukim.mk.lab1.services.domain.CountryService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CountryServiceImpl implements CountryService {

    private final CountryRepository countryRepository;

    public CountryServiceImpl(CountryRepository countryRepository) {
        this.countryRepository = countryRepository;
    }

    @Override
    public List<Country> findAll() {
        return this.countryRepository.findAll();
    }
}
