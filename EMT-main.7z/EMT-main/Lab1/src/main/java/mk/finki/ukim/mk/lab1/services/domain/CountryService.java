package mk.finki.ukim.mk.lab1.services.domain;

import mk.finki.ukim.mk.lab1.model.domain.Country;

import java.util.List;

public interface CountryService {
    List<Country> findAll();
}
