package mk.finki.ukim.mk.lab1.services.domain;

import mk.finki.ukim.mk.lab1.model.domain.Host;

import java.util.List;

public interface HostService {
    List<Host> findAll();
}
