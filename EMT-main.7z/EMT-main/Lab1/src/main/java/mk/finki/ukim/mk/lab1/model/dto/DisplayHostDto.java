package mk.finki.ukim.mk.lab1.model.dto;

import mk.finki.ukim.mk.lab1.model.domain.Host;

import java.util.List;
import java.util.stream.Collectors;

public record DisplayHostDto(Long id, String surname, String name) {
    public static DisplayHostDto from (Host host) {
        return new DisplayHostDto(host.getId(), host.getSurname(), host.getName());
    }
    public static List<DisplayHostDto> from (List<Host> hosts) {
        return hosts.stream().map(DisplayHostDto::from).collect(Collectors.toList());
    }
}
