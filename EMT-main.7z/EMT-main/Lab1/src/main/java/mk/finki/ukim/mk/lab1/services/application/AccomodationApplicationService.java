package mk.finki.ukim.mk.lab1.services.application;

import mk.finki.ukim.mk.lab1.model.AccomodationsDTO.AccomodationDto;
import mk.finki.ukim.mk.lab1.model.domain.Accomodation;
import mk.finki.ukim.mk.lab1.model.dto.CreateAccomodationDto;
import mk.finki.ukim.mk.lab1.model.dto.DisplayAccomodationDto;
import mk.finki.ukim.mk.lab1.model.enumerations.BookCategory;

import java.util.List;
import java.util.Optional;

public interface AccomodationApplicationService {

    List<DisplayAccomodationDto> findAll();
    void delete(Long id);
    Optional<DisplayAccomodationDto> update(Long id, CreateAccomodationDto createAccomodationDto);
    Optional<DisplayAccomodationDto> create(CreateAccomodationDto createAccomodationDto);
    Optional<DisplayAccomodationDto> reservation(Long id);
    Optional<DisplayAccomodationDto> findById(Long id);
    Optional<DisplayAccomodationDto> save(CreateAccomodationDto accomodationDto);
    List<DisplayAccomodationDto> searchAccommodations(String name, BookCategory category, Long host, Integer numRooms);

}
