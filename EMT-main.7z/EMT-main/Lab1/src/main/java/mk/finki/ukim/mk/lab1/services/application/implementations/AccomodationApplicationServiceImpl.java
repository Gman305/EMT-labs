package mk.finki.ukim.mk.lab1.services.application.implementations;

import io.swagger.v3.oas.annotations.Operation;
import mk.finki.ukim.mk.lab1.model.AccomodationsDTO.AccomodationDto;
import mk.finki.ukim.mk.lab1.model.dto.CreateAccomodationDto;
import mk.finki.ukim.mk.lab1.model.dto.DisplayAccomodationDto;
import mk.finki.ukim.mk.lab1.model.enumerations.BookCategory;
import mk.finki.ukim.mk.lab1.services.domain.AccomodationService;
import mk.finki.ukim.mk.lab1.services.application.AccomodationApplicationService;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AccomodationApplicationServiceImpl implements AccomodationApplicationService {

    private final AccomodationService accomodationService;


    public AccomodationApplicationServiceImpl(AccomodationService accomodationService) {
        this.accomodationService = accomodationService;
    }

    @Override
    public List<DisplayAccomodationDto> searchAccommodations(String name, BookCategory category, Long host, Integer numRooms) {
        return accomodationService.searchAccommodations(name, category, host, numRooms)
                .stream()
                .map(DisplayAccomodationDto::from)
                .collect(Collectors.toList());
    }


    @Override
    public List<DisplayAccomodationDto> findAll() {
        return accomodationService.findAll().stream()
                .map(DisplayAccomodationDto::from)
                .collect(Collectors.toList());
    }

    @Override
    public void delete(Long id) {
        accomodationService.delete(id);
    }

    @Override
    public Optional<DisplayAccomodationDto> update(Long id, CreateAccomodationDto createAccomodationDto) {
        return accomodationService.update(id, createAccomodationDto.toAccomodation())
                .map(DisplayAccomodationDto::from);
    }

    @Override
    public Optional<DisplayAccomodationDto> create(CreateAccomodationDto createAccomodationDto) {
        return accomodationService.create(createAccomodationDto.toAccomodation())
                .map(DisplayAccomodationDto::from);
    }

    @Override
    public Optional<DisplayAccomodationDto> reservation(Long id) {
        return accomodationService.reservation(id).map(DisplayAccomodationDto::from);
    }

    @Override
    public Optional<DisplayAccomodationDto> findById(Long id) {
        return accomodationService.findById(id).map(DisplayAccomodationDto::from);
    }

    @Override
    public Optional<DisplayAccomodationDto> save(CreateAccomodationDto accomodationDto) {
        return accomodationService.save(accomodationDto.toAccomodation()).map(DisplayAccomodationDto::from);
    }
}

