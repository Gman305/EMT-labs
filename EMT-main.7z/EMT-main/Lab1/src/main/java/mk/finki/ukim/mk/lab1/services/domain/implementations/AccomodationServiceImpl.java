package mk.finki.ukim.mk.lab1.services.domain.implementations;

import mk.finki.ukim.mk.lab1.model.AccomodationsDTO.AccomodationDto;
import mk.finki.ukim.mk.lab1.model.domain.Accomodation;
import mk.finki.ukim.mk.lab1.model.enumerations.BookCategory;
import mk.finki.ukim.mk.lab1.repository.AccomodationRepository;
import mk.finki.ukim.mk.lab1.repository.HostRepository;
import mk.finki.ukim.mk.lab1.services.domain.AccomodationService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AccomodationServiceImpl implements AccomodationService {

    private final AccomodationRepository accomodationRepository;
    private final HostRepository hostRepository;

    public AccomodationServiceImpl(AccomodationRepository accomodationRepository, HostRepository hostRepository) {
        this.accomodationRepository = accomodationRepository;
        this.hostRepository = hostRepository;
    }

    @Override
    public List<Accomodation> findAll() {
        return accomodationRepository.findAll();
    }

    @Override
    public void delete(Long id) {
        Accomodation accomodation=this.accomodationRepository.findById(id).orElseThrow(() -> new RuntimeException("This accomodation does not exist"));
        accomodationRepository.delete(accomodation);
    }

    @Override
    public Optional<Accomodation> update(Long id, Accomodation accomodation) {
        return accomodationRepository.findById(id).map(existingAccomodation -> {
            if(accomodation.getName()!=null) {
                existingAccomodation.setName(accomodation.getName());
            }
            if(accomodation.getCategory()!=null) {
                existingAccomodation.setCategory(accomodation.getCategory());
            }
            if(accomodation.getHost()!=null) {
                existingAccomodation.setHost(accomodation.getHost());
            }
            if(accomodation.getNumRooms()>0){
                existingAccomodation.setNumRooms(accomodation.getNumRooms());
            }
            return accomodationRepository.save(existingAccomodation);
        });
    }

    @Override
    public Optional <Accomodation> create(Accomodation accomodation) {
        Accomodation accomodation1=new Accomodation();
        accomodation1.setName(accomodation.getName());
        accomodation1.setCategory(accomodation.getCategory());
        accomodation1.setHost(accomodation.getHost());
        accomodation1.setNumRooms(accomodation.getNumRooms());
        return Optional.of(accomodationRepository.save(accomodation1));
    }

    @Override
    public Optional <Accomodation> reservation(Long id) {
        Accomodation accommodation = this.accomodationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Accommodation with ID " + id + " not found!"));

        if (accommodation.isBooked()) {
            throw new RuntimeException("Accommodation with ID " + id + " is already booked!");
        }

        accommodation.setBooked(true);
        return Optional.of(this.accomodationRepository.save(accommodation));
    }

    @Override
    public Optional<Accomodation> findById(Long id) {
        return accomodationRepository.findById(id);
    }

    @Override
    public Optional<Accomodation> save(Accomodation accomodation) {
        return Optional.of(accomodationRepository.save(accomodation));
    }

    @Override
    public List<Accomodation> searchAccommodations(String name, BookCategory category, Long host, Integer numRooms) {
        return accomodationRepository.findAll().stream()
                .filter(a -> name == null || a.getName().toLowerCase().contains(name.toLowerCase()))
                .filter(a -> category == null || a.getCategory().equals(category))
                .filter(a -> host == null || a.getHost().equals(host))
                .filter(a -> numRooms == null || a.getNumRooms() == numRooms)
                .collect(Collectors.toList());
    }

    private AccomodationDto mapToDisplayDto(Accomodation acc) {

        return new AccomodationDto(
                acc.getName(),
                acc.getCategory(),
                acc.getId(),
                acc.getNumRooms()
        );
    }

}