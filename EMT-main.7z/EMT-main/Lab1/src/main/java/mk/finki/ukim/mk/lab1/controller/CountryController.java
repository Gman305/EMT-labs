package mk.finki.ukim.mk.lab1.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.finki.ukim.mk.lab1.services.application.CountryApplicationService;
import org.springframework.http.ResponseEntity;
import mk.finki.ukim.mk.lab1.model.dto.DisplayCountryDto;
import mk.finki.ukim.mk.lab1.model.dto.CreateCountryDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/countries")
@Tag(name = "Country API", description = "Endpoints for managing countries")
public class CountryController {

    private final CountryApplicationService countryapplicationService;

    public CountryController(CountryApplicationService countryapplicationService) {
        this.countryapplicationService = countryapplicationService;
    }


    @Operation(summary = "Get all countries", description = "Returns all countries")
    @GetMapping
    public List<DisplayCountryDto> getAll()
    {
        return countryapplicationService.findAll();
    }
}
