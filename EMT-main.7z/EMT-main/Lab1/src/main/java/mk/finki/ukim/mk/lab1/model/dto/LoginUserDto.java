package mk.finki.ukim.mk.lab1.model.dto;

public record LoginUserDto(String username, String password) {
}
