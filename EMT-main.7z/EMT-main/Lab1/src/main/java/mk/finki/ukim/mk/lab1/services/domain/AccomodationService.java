package mk.finki.ukim.mk.lab1.services.domain;

import mk.finki.ukim.mk.lab1.model.domain.Accomodation;
import mk.finki.ukim.mk.lab1.model.enumerations.BookCategory;

import java.util.List;
import java.util.Optional;

public interface AccomodationService {

    List<Accomodation> findAll();
    void delete(Long id);
    Optional <Accomodation> update(Long id, Accomodation accomodation);
    Optional <Accomodation> create(Accomodation accomodation);
    Optional<Accomodation> reservation(Long id);
    Optional<Accomodation> findById(Long id);
    Optional<Accomodation> save(Accomodation accomodation);
    List<Accomodation> searchAccommodations(String name, BookCategory category, Long host, Integer numRooms);


}
