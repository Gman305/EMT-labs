package mk.finki.ukim.mk.lab1.services.domain.implementations;

import mk.finki.ukim.mk.lab1.model.domain.Host;
import mk.finki.ukim.mk.lab1.repository.HostRepository;
import mk.finki.ukim.mk.lab1.services.domain.HostService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HostServiceImpl implements HostService {

    private final HostRepository hostRepository;

    public HostServiceImpl(HostRepository hostRepository) {
        this.hostRepository = hostRepository;
    }

    @Override
    public List<Host> findAll() {
        return this.hostRepository.findAll();
    }
}
