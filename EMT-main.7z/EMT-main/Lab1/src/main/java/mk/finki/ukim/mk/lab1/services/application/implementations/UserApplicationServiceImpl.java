package mk.finki.ukim.mk.lab1.services.application.implementations;

import mk.finki.ukim.mk.lab1.model.domain.Accomodation;
import mk.finki.ukim.mk.lab1.model.domain.User;
import mk.finki.ukim.mk.lab1.model.dto.CreateUserDto;
import mk.finki.ukim.mk.lab1.model.dto.DisplayAccomodationDto;
import mk.finki.ukim.mk.lab1.model.dto.DisplayUserDto;
import mk.finki.ukim.mk.lab1.model.dto.LoginUserDto;
import mk.finki.ukim.mk.lab1.services.application.UserApplicationService;
import mk.finki.ukim.mk.lab1.services.domain.UserService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@Service
public class UserApplicationServiceImpl implements UserApplicationService {
    private final UserService userService;

    public UserApplicationServiceImpl(UserService userService) {
        this.userService = userService;
    }

    public Optional<DisplayUserDto> register(CreateUserDto createUserDto) {
        User user = userService.register(
                createUserDto.username(),
                createUserDto.password(),
                createUserDto.repeatPassword(),
                createUserDto.name(),
                createUserDto.surname(),
                createUserDto.role()
        );
        return Optional.of(DisplayUserDto.from(user));
    }

    @Override
    public Optional<DisplayUserDto> login(LoginUserDto loginUserDto) {
        return Optional.of(DisplayUserDto.from(userService.login(
                loginUserDto.username(),
                loginUserDto.password()
        )));
    }

    @Override
    public Optional<DisplayUserDto> findByUsername(String username) {
        return Optional.of(DisplayUserDto.from(userService.findByUsername(username)));
    }

    @Override
    public List<DisplayAccomodationDto> addToTemporaryReservationList(String username, Long id) {
        User user = userService.findByUsername(username);
        userService.addToTemporaryReservationList(username,id);
        List<Accomodation> accomodations = user.getAccomodations();
        return accomodations.stream().map(DisplayAccomodationDto::from).collect(Collectors.toList());
    }

    @Override
    public List<DisplayAccomodationDto> getTemporaryReservationList(String username) {
        return userService.getTemporaryReservationList(username)
                .stream()
                .map(DisplayAccomodationDto::from)
                .collect(Collectors.toList());
    }

    @Override
    public List<DisplayAccomodationDto> confirmAllReservations(String username) {
        return userService.confirmAllReservations(username)
                .stream()
                .map(DisplayAccomodationDto::from)
                .collect(Collectors.toList());
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return userService.loadUserByUsername(username);
    }
}