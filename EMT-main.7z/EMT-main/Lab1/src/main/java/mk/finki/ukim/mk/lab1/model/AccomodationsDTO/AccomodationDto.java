package mk.finki.ukim.mk.lab1.model.AccomodationsDTO;


import lombok.Data;
import mk.finki.ukim.mk.lab1.model.enumerations.BookCategory;

@Data
public class AccomodationDto {

    private String name;
    private BookCategory category;
    private Long host;
    private int numRooms;

    public AccomodationDto() {
    }

    public AccomodationDto(String name, BookCategory category, Long host, int numRooms) {
        this.name = name;
        this.category = category;
        this.host = host;
        this.numRooms = numRooms;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BookCategory getCategory() {
        return category;
    }

    public void setCategory(BookCategory category) {
        this.category = category;
    }

    public Long getHost() {
        return host;
    }

    public void setHost(Long host) {
        this.host = host;
    }

    public int getNumRooms() {
        return numRooms;
    }

    public void setNumRooms(int numRooms) {
        this.numRooms = numRooms;
    }
}
