package mk.finki.ukim.mk.lab1.model.exceptions;

public class InvalidUsernameOrPasswordException extends RuntimeException {
}
